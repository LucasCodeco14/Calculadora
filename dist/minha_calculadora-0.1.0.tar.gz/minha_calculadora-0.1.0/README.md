
# Minha Calculadora

Uma biblioteca Python com operações matemáticas básicas, incluindo tratamento de erros via FastAPI.

## Como usar

```python
from calculadora import dividir

resultado = dividir(10, 2)
print(resultado)  # 5.0
```
